export interface Iusuario {
    _id: string;
    id: number;
    first_name: string;
    last_name: string;
    username: string;
    email: string;
    image: string;
    password: string;
}
