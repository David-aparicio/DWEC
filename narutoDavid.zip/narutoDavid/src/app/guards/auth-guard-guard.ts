import { inject } from '@angular/core';
import { CanActivateFn, Router } from '@angular/router';

export const authGuardGuard: CanActivateFn = (route, state) => {
  const router = inject(Router);
  const token = localStorage.getItem('token');

  if (token) {
    return true; // ✅ Permite el acceso
  }
  
  // Si no hay token, redirige a login
  router.navigate(['/login']);
  return false;
};
